# Amaal ERP

Amaal is a closed, single-company internal ERP and intelligent operations platform for smartphone sales, IMEI-centric inventory, field distribution, receipts, payments, commissions, recovery, approvals, reporting and governed AI operations.

## Current architecture

- **Vercel** — Next.js/React/TypeScript frontend and PWA surface
- **Render** — API and background worker services
- **Render Valkey** — cache, queues, coordination and short-lived state
- **Neon PostgreSQL** — authoritative transactional database
- **Neon Auth / Better Auth** — current production identity/session boundary; development MFA remains disabled
- **Supabase Storage** — not the transactional source; use only for the approved private-file workflows still backed by Supabase
- **OpenAI** — governed Amaal AI intelligence/orchestration
- **GitHub** — source control and CI/CD source

### Important hosting decision

Neon PostgreSQL is now the production database of record. Supabase PostgreSQL is no longer the Amaal source of transactional truth. The application connects to Neon through `AMAAL_DATABASE_URL`.

Supabase remains only where explicitly retained for legacy/supporting workflows. Identity/session handling is moving through Neon Auth; the database, audit trail, outbox, read models and transactional writes live in Neon.

## Source of truth

Read the current continuation document first: `AMAAL_CONTINUATION_2026-09-30.md`. Then use `docs/` for the active architecture/contracts. The approved Amaal specifications remain authoritative for product/domain behavior; current infrastructure documents record the implemented provider mapping. Historical snapshots under `docs/project-history/` are preserved and should not be treated as the current hosting configuration.

## Implementation rule

The system is database-first, authorization-first and transaction-first. Do not build fake dashboards, fake authentication, fake inventory or client-side-only business behavior. Amaal AI never receives unrestricted SQL authority.

## Current foundation status

- Neon production is the authoritative transactional database.
- Neon Auth / Better Auth is provisioned on the production branch; the production frontend auth route now responds successfully.
- Render `amaal-api` and `amaal-worker` are deployed from `main`; API `/health` and `/ready` are healthy, with `/ready` confirming the database.
- Render Valkey/Redis remains non-authoritative and is reserved for transient coordination, queues, cache and realtime fan-out.
- Amaal AI is the active product term for the governed AI layer. Historical documentation that uses the former assistant name is preserved.
- Development MFA remains disabled until the Phase 2 security gate is complete.
- GitHub source synchronization currently requires the connected GitHub account to complete its MFA authorization; no claim is made that the updated Phase 0 package has been pushed from this session.

## Vercel deployment correction — 1 October 2026

The Next.js frontend is deployed independently from the pnpm/Turborepo workspace install. Vercel installs and builds from `apps/web` with npm so a pnpm registry/client failure cannot block the web build. Render and the root monorepo continue to use pnpm/Turborepo.

## Phase 0 — Foundation & Architecture Freeze

Phase 0 is the current Amaal delivery gate. The approved specifications remain authoritative; Neon PostgreSQL is the transactional source of truth; Vercel is the frontend; Render is the application/API and worker boundary; Supabase is transitional/historical only.

See `docs/AMAAL_WORK_PHASES.md`, `docs/phase0/AMAAL_PHASE0_FOUNDATION.md` and `docs/phase0/AMAAL_TECHNOLOGY_STACK_AND_PHASE_PLAN.md`.



## Current delivery gate — Phase 1
Phase 1 is explicitly tracked as Amaal Setup: company foundation, four main regions, standard regional warehouses, pending CEO definition, policy-readiness markers, atomic audit/outbox completion and setup readiness verification.

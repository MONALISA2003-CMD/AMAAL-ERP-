"""Amaal ML workspace marker."""

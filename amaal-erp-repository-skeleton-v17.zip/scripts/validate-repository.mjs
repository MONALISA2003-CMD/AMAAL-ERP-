import { existsSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const root = process.cwd();
const required = [
  '.github/workflows/zip-sync.yml',
  'docs/source-specifications/AMAAL_MASTER_SYSTEM_SPECIFICATION-1.md',
  'docs/source-specifications/AMAAL_DATABASE_AND_AUTHORIZATION_BLUEPRINT-1.md',
  'docs/source-specifications/AMAAL_LLM_HANDOFF_MASTER.md',
  'docs/AMAAL_DOMAIN_MODEL.md',
  'docs/AMAAL_STATE_MACHINES.md',
  'docs/AMAAL_AUTHORIZATION_MATRIX.md',
  'docs/AMAAL_EVENT_CATALOG.md',
  'docs/AMAAL_API_CONTRACT.md',
  'docs/AMAAL_JARVIS_TOOL_CONTRACT.md',
  'database/migrations/20260928_000001_core_foundation.sql',
  'database/policies/20260928_rls_foundation.sql',
  'database/verification/20260928_core_foundation_verify.sql',
  'packages/business-rules/src/index.ts',
  'packages/permissions/src/index.ts',
  'packages/database/src/index.ts'
];

const missing = required.filter((p) => !existsSync(join(root, p)));
if (missing.length) {
  console.error('Missing required repository files:');
  for (const path of missing) console.error(`- ${path}`);
  process.exit(1);
}

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (name === '.git' || name === '.sync-staging' || name === '.sync-backup') continue;
    if (st.isDirectory()) out.push(...walk(full));
    else out.push(relative(root, full));
  }
  return out;
}

const docs = walk(root).filter((p) => /\.(md|markdown|doc|docx|mdx)$/i.test(p));
console.log(`Amaal repository validation passed. Documentation files present: ${docs.length}`);
